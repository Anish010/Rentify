using BAL;
using BAL.Interfaces;
using DAL;
using DAL.Interfaces;
using DB.Context;
using Microsoft.EntityFrameworkCore;
using Rentify.BAL;
using Rentify.BAL.Interfaces;
using Rentify.DAL;
using Rentify.DAL.Interfaces;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

// Configure Serilog first
Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Debug()
    .WriteTo.Console()
    .WriteTo.File("logs/EMSLogs.log", rollingInterval: RollingInterval.Day)
    .CreateLogger();

builder.Services.AddCors(options =>
    {
        options.AddPolicy("AllowAll",
            builder =>
            {
                builder.AllowAnyOrigin()
                       .AllowAnyMethod()
                       .AllowAnyHeader();
            });
    });

builder.Services.AddSingleton<Serilog.ILogger>(Log.Logger);

// Register services
builder.Services.AddScoped<IUserBAL, UserBAL>();
builder.Services.AddScoped<IUserDAL, UserDAL>();
builder.Services.AddScoped<IPropertyBAL, PropertyBAL>();
builder.Services.AddScoped<IPropertyDAL, PropertyDAL>();
builder.Services.AddScoped<IAuthBAL, AuthBAL>();
builder.Services.AddScoped<IAuthDAL, AuthDAL>();


// Add DbContext
builder.Services.AddDbContext<RentifyDBContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseCors("AllowAll");

app.UseRouting();
app.UseAuthentication();
app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();

app.Run();