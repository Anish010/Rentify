using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DB.Context;
using DB.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Rentify.DAL.DTOs;
using Rentify.DAL.Interfaces;
using Rentify.DAL.Mappers;

namespace Rentify.DAL
{
    public class PropertyDAL : IPropertyDAL
    {
        private readonly RentifyDBContext _context;
        private readonly IPropertyMapper _mapper;

        public PropertyDAL(RentifyDBContext context)
        {
            _context = context;
            _mapper = new PropertyMapper();
        }

        public async Task<List<Property>> RetrieveAllPropertiesAsync()
        {
            return await _context.Properties.ToListAsync();
        }

        public async Task<Property?> RetrievePropertyByIdAsync(int id)
        {
            var property = await _context.Properties.FindAsync(id);
            if (property == null)
            {
                return null;
            }
            return property;
        }

        public async Task<Property> CreatePropertyAsync(PropertyDto property)
        {
            var newProperty = _mapper.ToPropertyModel(property);
            _context.Properties.Add(newProperty!);
            await _context.SaveChangesAsync();
            return newProperty!;
        }

        public async Task<List<Property>> RetrievePropertyByOwnerId(int ownerId)
        {
            var properties = await _context.Properties
                .Where(p => p.OwnerId == ownerId)
                .ToListAsync();

            return properties;
        }

        public async Task<List<Property>> RetrievePropertyByRenterId(int renterId)
        {
            var properties = await _context.Properties
                .Where(p => p.RenterId == renterId)
                .ToListAsync();

            return properties;
        }

        public async Task<int> UpdatePropertyAsync(int id, PropertyDto property)
        {
            var propertyToUpdate = await _context.Properties.FindAsync(id);
            if (propertyToUpdate == null)
            {
                return 0;
            }

            propertyToUpdate.Area = property.Area;
            propertyToUpdate.Bedrooms = property.Bedrooms;
            propertyToUpdate.Bathrooms = property.Bathrooms;
            propertyToUpdate.NearbyHospitals = property.NearbyHospitals!;
            propertyToUpdate.NearbyColleges = property.NearbyColleges!;
            propertyToUpdate.Place = property.Place!;

            int rowsAffected = await _context.SaveChangesAsync();
            return rowsAffected;
        }

        public async Task<int> DeletePropertyAsync(int id)
        {
            var property = await _context.Properties.FindAsync(id);
            if (property == null)
            {
                return 0;
            }

            _context.Properties.Remove(property);
            int rowsAffected = await _context.SaveChangesAsync();
            return rowsAffected;
        }

        public async Task<List<Property>> RetrievePropertiesAvailable()
        {
            var properties = await _context.Properties
                .Where(p => p.RenterId == null)
                .ToListAsync();

            return properties;
        }
    }
}