using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Rentify.DAL.DTOs
{
    public class PropertyDto
    {
        public string? Place { get; set; }
        public int OwnerId { get; set; } = 1;
        public decimal Area { get; set; }

        public int Bedrooms { get; set; }
        public int? RenterId { get; set; }
        public int Bathrooms { get; set; }
        public string? NearbyHospitals { get; set; }

        public string? NearbyColleges { get; set; }
    }
}