using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace Rentify.DAL.DTOs
{
    public class AuthenticateRequest
    {
        [DefaultValue("john@example.com")]
        public required string Email { get; set; }

        [DefaultValue("12345678")]
        public required string Password { get; set; }
    }
}