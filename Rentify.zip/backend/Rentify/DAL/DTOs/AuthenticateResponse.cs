using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Rentify.DAL.DTOs
{
    public class AuthenticateResponse
    {
        public bool IsAuthenticated { get; set; } = false;
        public int? UserId { get; set; } = null;
        public string? FirstName { get; set; } = null;
        public string? LastName { get; set; } = null;
        public string? Email { get; set; } = null;
        public int? RoleId { get; set; } = null;
        public string? Password { get; set; } = null;
    }
}