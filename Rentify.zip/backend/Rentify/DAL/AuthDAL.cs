using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DAL.DTOs;
using DAL.Interfaces;
using DAL.Mappers;
using DB.Context;
using Microsoft.EntityFrameworkCore;
using Rentify.DAL.DTOs;
using Rentify.DAL.Interfaces;
using Rentify.DAL.Mappers;

namespace Rentify.DAL
{
    public class AuthDAL : IAuthDAL
    {
        private readonly RentifyDBContext _context;
        private readonly IAuthMapper _authMapper;
        private readonly IUserMapper _userMapper;

        public AuthDAL(RentifyDBContext context)
        {
            _context = context;
            _authMapper = new AuthMapper();
            _userMapper = new UserMapper();
        }

        public async Task<AuthenticateResponse?> AuthenticateUserAsync(string email)
        {
            var user = await _context.Users.SingleOrDefaultAsync(u => u.Email == email);
            if (user == null)
            {
                return null;
            }
            return _authMapper.ToAuthResponse(user, true);
        }

        public async Task<AuthenticateResponse?> RegisterUserAsync(UserDto user)
        {
            var newUser = _userMapper.ToUserModel(user);
            _context.Users.Add(newUser!);
            int rowsAffected = await _context.SaveChangesAsync();
            if (rowsAffected == 0)
            {
                return new AuthenticateResponse();
            }
            return _authMapper.ToAuthResponse(newUser, true);
        }
    }
}