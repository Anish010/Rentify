using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DB.Models;
using Rentify.DAL.DTOs;
using Rentify.DAL.Interfaces;

namespace Rentify.DAL.Mappers
{
    public class PropertyMapper : IPropertyMapper
    {
        public Property ToPropertyModel(PropertyDto propertyDto)
        {
            return new Property
            {
                OwnerId = propertyDto.OwnerId,
                Place = propertyDto.Place,
                Area = propertyDto.Area,
                Bedrooms = propertyDto.Bedrooms,
                Bathrooms = propertyDto.Bathrooms,
                NearbyHospitals = propertyDto.NearbyHospitals,
                NearbyColleges = propertyDto.NearbyColleges
            };
        }
    }
}