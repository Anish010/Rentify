using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DB.Models;
using Rentify.DAL.DTOs;
using Rentify.DAL.Interfaces;

namespace Rentify.DAL.Mappers
{
    public class AuthMapper : IAuthMapper
    {
        public AuthenticateResponse? ToAuthResponse(User user, bool isAuth)
        {
            if (user == null)
            {
                return new AuthenticateResponse();
            }

            return new AuthenticateResponse
            {
                IsAuthenticated = isAuth,
                UserId = user.Id,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                RoleId = user.RoleId,
                Password = user.Password
            };
        }
    }
}