using DAL.DTOs;
using DAL.Interfaces;
using DB.Models;

namespace DAL.Mappers
{
    public class UserMapper : IUserMapper
    {
        public UserDto? ToUserDto(User user)
        {
            if (user == null)
            {
                return null;
            }

            return new UserDto
            {
                Id = user.Id,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                PhoneNumber = user.PhoneNumber,
                RoleId = user.RoleId
            };
        }

        public List<UserDto> ToUserDto(IEnumerable<User> users)
        {
            return users.Select(user => ToUserDto(user)).ToList()!;
        }

        public User ToUserModel(UserDto userDto)
        {
            return new User
            {
                Id = userDto.Id,
                FirstName = userDto.FirstName,
                LastName = userDto.LastName,
                Email = userDto.Email,
                PhoneNumber = userDto.PhoneNumber,
                RoleId = userDto.RoleId
            };
        }
    }
}