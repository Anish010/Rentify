using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DB.Models;
using Rentify.DAL.DTOs;

namespace Rentify.DAL.Interfaces
{
    public interface IPropertyDAL
    {
        public Task<List<Property>> RetrieveAllPropertiesAsync();
        public Task<Property?> RetrievePropertyByIdAsync(int id);
        public Task<Property> CreatePropertyAsync(PropertyDto property);
        public Task<List<Property>> RetrievePropertyByOwnerId(int ownerId);
        public Task<List<Property>> RetrievePropertyByRenterId(int renterId);
        public Task<int> UpdatePropertyAsync(int id, PropertyDto property);
        public Task<int> DeletePropertyAsync(int id);
        public Task<List<Property>> RetrievePropertiesAvailable();
    }
}