using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DAL.DTOs;
using Rentify.DAL.DTOs;

namespace Rentify.DAL.Interfaces
{
    public interface IAuthDAL
    {
        public Task<AuthenticateResponse?> AuthenticateUserAsync(string email);
        public Task<AuthenticateResponse?> RegisterUserAsync(UserDto user);
    }
}