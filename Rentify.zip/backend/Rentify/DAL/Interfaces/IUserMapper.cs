using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DAL.DTOs;
using DB.Models;

namespace DAL.Interfaces
{
    public interface IUserMapper
    {
        public UserDto? ToUserDto(User user);
        public List<UserDto> ToUserDto(IEnumerable<User> users);
        public User ToUserModel(UserDto userDto);
    }
}