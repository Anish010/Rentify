using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DB.Models;
using Rentify.DAL.DTOs;

namespace Rentify.DAL.Interfaces
{
    public interface IPropertyMapper
    {
        public Property? ToPropertyModel(PropertyDto propertyDto);
    }
}