using DAL.DTOs;
using DAL.Interfaces;
using DAL.Mappers;
using DB.Context;
using Microsoft.EntityFrameworkCore;

namespace DAL
{
    public class UserDAL : IUserDAL
    {
        private readonly RentifyDBContext _context;
        private readonly IUserMapper _mapper;

        public UserDAL(RentifyDBContext context)
        {
            _context = context;
            _mapper = new UserMapper();
        }

        public async Task<List<UserDto>> RetrieveAllUsersAsync()
        {
            var users = await _context.Users.ToListAsync();
            return _mapper.ToUserDto(users);
        }
    }
}