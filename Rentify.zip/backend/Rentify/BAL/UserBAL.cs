using BAL.Interfaces;
using DAL.DTOs;
using DAL.Interfaces;
using ILogger = Serilog.ILogger;

namespace BAL
{
    public class UserBAL : IUserBAL
    {
        private readonly IUserDAL _userDal;
        private readonly ILogger _logger;

        public UserBAL(ILogger logger, IUserDAL userDal)
        {
            _userDal = userDal;
            _logger = logger;
        }

        public async Task<List<UserDto>?> GetAllAsync()
        {
            try
            {
                var employees = await _userDal.RetrieveAllUsersAsync();
                return employees;
            }
            catch (Exception ex)
            {
                _logger.Error($"Error retrieving users: {ex.Message}");
                throw;
            }
        }
    }
}