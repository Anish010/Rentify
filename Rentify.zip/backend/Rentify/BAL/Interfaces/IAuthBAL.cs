using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DAL.DTOs;
using Rentify.DAL.DTOs;

namespace Rentify.BAL.Interfaces
{
    public interface IAuthBAL
    {
        public Task<AuthenticateResponse?> AuthenticateAsync(string email);
        public Task<AuthenticateResponse?> RegisterAsync(UserDto user);
    }
}