using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DB.Models;
using Rentify.DAL.DTOs;

namespace Rentify.BAL.Interfaces
{
    public interface IPropertyBAL
    {
        public Task<List<Property>> GetAllPropertiesAsync();
        public Task<Property?> RetrievePropertyByIdAsync(int id);
        public  Task<Property> CreatePropertyAsync(PropertyDto property);
        public Task<List<Property>> RetrievePropertyByOwnerId(int ownerId);
        public Task<List<Property>> RetrievePropertyByRenterId(int renterId);
        public Task<int> UpdatePropertyAsync(int id, PropertyDto property);
        public Task<int> DeletePropertyAsync(int id);
        public Task<List<Property>> RetrievePropertiesAvailable();
    }
}