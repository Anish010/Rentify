using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DAL.DTOs;

namespace BAL.Interfaces
{
    public interface IUserBAL
    {
        public Task<List<UserDto>?> GetAllAsync();
    }
}