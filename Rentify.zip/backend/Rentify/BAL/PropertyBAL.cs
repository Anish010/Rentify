using ILogger = Serilog.ILogger;
using DB.Models;
using Rentify.BAL.Interfaces;
using Rentify.DAL.Interfaces;
using Rentify.DAL.DTOs;

namespace Rentify.BAL
{
    public class PropertyBAL : IPropertyBAL
    {
        private readonly IPropertyDAL _propertyDAL;
        private readonly ILogger _logger;
        public PropertyBAL(ILogger logger, IPropertyDAL propertyDAL)
        {
            _propertyDAL = propertyDAL;
            _logger = logger;
        }

        public async Task<List<Property>> GetAllPropertiesAsync()
        {
            try
            {
                return await _propertyDAL.RetrieveAllPropertiesAsync();
            }
            catch (Exception ex)
            {
               _logger.Error($"Error retrieving properties: {ex.Message}");
                throw;
            }
        }

        public async Task<Property?> RetrievePropertyByIdAsync(int id)
        {
            try
            {
                return await _propertyDAL.RetrievePropertyByIdAsync(id);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error retrieving property: {ex.Message}");
                throw;
            }
        }

        public async Task<Property> CreatePropertyAsync(PropertyDto property)
        {
            try
            {
                return await _propertyDAL.CreatePropertyAsync(property);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error creating property: {ex.Message}");
                throw;
            }
        }

        public async Task<List<Property>> RetrievePropertyByOwnerId(int ownerId)
        {
            try
            {
                return await _propertyDAL.RetrievePropertyByOwnerId(ownerId);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error retrieving properties by owner: {ex.Message}");
                throw;
            }
        }

        public async Task<int> UpdatePropertyAsync(int id, PropertyDto property)
        {
            try
            {
                return await _propertyDAL.UpdatePropertyAsync(id, property);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error updating property: {ex.Message}");
                throw;
            }
        }

        public async Task<int> DeletePropertyAsync(int id)
        {
            try
            {
                return await _propertyDAL.DeletePropertyAsync(id);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error deleting property: {ex.Message}");
                throw;
            }
        }

        public async Task<List<Property>> RetrievePropertyByRenterId(int renterId)
        {
            try
            {
                return await _propertyDAL.RetrievePropertyByRenterId(renterId);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error retrieving properties by renter: {ex.Message}");
                throw;
            }
        }

        public async Task<List<Property>> RetrievePropertiesAvailable()
        {
            try
            {
                return await _propertyDAL.RetrievePropertiesAvailable();
            }
            catch (Exception ex)
            {
                _logger.Error($"Error retrieving available properties: {ex.Message}");
                throw;
            }
        }
    }
}