using DAL.DTOs;
using Rentify.BAL.Interfaces;
using Rentify.DAL.DTOs;
using Rentify.DAL.Interfaces;
using ILogger = Serilog.ILogger;

namespace Rentify.BAL
{
    public class AuthBAL : IAuthBAL
    {
        private readonly IAuthDAL _authDal;
        private readonly ILogger _logger;

        public AuthBAL(ILogger logger, IAuthDAL authDal)
        {
            _authDal = authDal;
            _logger = logger;
        }
        public async Task<AuthenticateResponse?> AuthenticateAsync(string email)
        {
            try
            {
                return await _authDal.AuthenticateUserAsync(email) ?? null;
            }
            catch (Exception ex)
            {
                _logger.Error($"Error in authenticating user: {ex.Message}");
                throw;
            }
        }

        public async Task<AuthenticateResponse?> RegisterAsync(UserDto user)
        {
            try
            {
                return await _authDal.RegisterUserAsync(user);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error occurred while inserting user: {ex.Message}");
                throw;
            }
        }
    }
}