using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DB.Models
{
    public class Property
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(TypeName = "int")]
        public int Id { get; set; }

        public int OwnerId { get; set; }
        [MaxLength(255)]
        [Column(TypeName = "nvarchar(255)")]
        public string Place { get; set; }

        [Column(TypeName = "DECIMAL(10,2)")]
        public decimal Area { get; set; }

        [Column(TypeName = "int")]
        public int Bedrooms { get; set; }

        [Column(TypeName = "int")]
        public int Bathrooms { get; set; }
        [MaxLength(255)]
        [Column(TypeName = "nvarchar(255)")]
        public string NearbyHospitals { get; set; }
        [MaxLength(255)]
        [Column(TypeName = "nvarchar(255)")]
        public string NearbyColleges { get; set; }

        // Foreign key for owner
        [ForeignKey("OwnerId")]
        public User Owner { get; set; }

        // Foreign key for renter
        public int? RenterId { get; set; }
        [ForeignKey("RenterId")]
        public User Renter { get; set; }
    }
}
