using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Rentify.DB.Models;

namespace DB.Models
{
    public class User
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(TypeName = "int")]
        public int Id { get; set; }

        [MaxLength(255)]
        [Column(TypeName = "nvarchar(255)")]
        public string FirstName { get; set; }

        [MaxLength(255)]
        [Column(TypeName = "nvarchar(255)")]
        public string LastName { get; set; }
        [MaxLength(255)]
        [Column(TypeName = "nvarchar(255)")]
        public string Email { get; set; }
        [MaxLength(20)]
        [Column(TypeName = "nvarchar(20)")]
        public string PhoneNumber { get; set; }

        public int RoleId { get; set; }

         [MaxLength(20)]
        [Column(TypeName = "nvarchar(20)")]
        public string Password { get; set; }

        [ForeignKey("RoleId")]
        public Role? Role { get; set; }

        public virtual ICollection<Property> PropertiesOwned { get; set; }
        public virtual ICollection<Property> PropertiesRented { get; set; }
    }
}