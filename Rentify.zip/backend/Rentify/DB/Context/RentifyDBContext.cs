using System;
using DB.Models;
using Microsoft.EntityFrameworkCore;
using Rentify.DB.Models;

namespace DB.Context
{
    public class RentifyDBContext : DbContext
    {
        private readonly IConfiguration? _configuration;

        public RentifyDBContext()
        {
        }

        public RentifyDBContext(DbContextOptions dbContextOptions, IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public DbSet<User> Users { get; set; }
        public DbSet<Property> Properties { get; set; }
        public DbSet<Role> Roles { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string connectionString = _configuration!["ConnectionStrings:DefaultConnection"]!;
            optionsBuilder.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString));
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>()
                .HasKey(u => u.Id);

            modelBuilder.Entity<Property>()
                .HasKey(p => p.Id);

            modelBuilder.Entity<Role>()
                .HasKey(r => r.Id);

            modelBuilder.Entity<Property>()
                .HasOne(p => p.Owner)
                .WithMany(u => u.PropertiesOwned)
                .HasForeignKey(p => p.OwnerId)
                .IsRequired(false);

            modelBuilder.Entity<Property>()
                .HasOne(p => p.Renter)
                .WithMany(u => u.PropertiesRented)
                .HasForeignKey(p => p.RenterId)
                .IsRequired(false);

            modelBuilder.Entity<User>()
                .HasOne(u => u.Role)
                .WithMany(r => r.Users)
                .HasForeignKey(u => u.RoleId)
                .IsRequired(false);

        }
    }
}