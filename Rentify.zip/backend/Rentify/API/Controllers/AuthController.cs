using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using API.Helpers;
using DAL.DTOs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Rentify.API.Helpers;
using Rentify.BAL.Interfaces;
using Rentify.DAL.DTOs;
using ILogger = Serilog.ILogger;

namespace Rentify.API.Controllers
{
    [Route("/Auth")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthBAL _authBal;
        private readonly ILogger _logger;

        public AuthController(ILogger logger, IAuthBAL authBAL)
        {
            _logger = logger;
            _authBal = authBAL;
        }

        [AllowAnonymous]
        [HttpPost("Login")]
        public async Task<IActionResult> LoginAsync(AuthenticateRequest model)
        {
            try
            {
                AuthenticateResponse? authResponse = await _authBal.AuthenticateAsync(model.Email);
                if (authResponse == null || model.Password != authResponse!.Password)
                {
                    return ResponseHelper.WrapResponse(401, "error", "Invalid email or password");
                }

                authResponse.Password = null;

                var responseData = new
                {
                    AuthResponse = authResponse,
                };

                return ResponseHelper.WrapResponse(200, StatusMessage.SUCCESS.ToString(), responseData);
            }
            catch (Exception)
            {
                return ResponseHelper.WrapResponse(500, "error", null, ErrorCodes.FAILED_TO_AUTHENTICATE.ToString());
            }
        }

        [HttpPost("Register")]
        public async Task<IActionResult> Register([FromBody] UserDto user)
        {
            try
            {
                var response = await _authBal.RegisterAsync(user);
                return ResponseHelper.WrapResponse(200, StatusMessage.SUCCESS.ToString(), response);
            }
            catch (Exception)
            {
                return ResponseHelper.WrapResponse(500, "error", null, ErrorCodes.FAILED_TO_REGISTER_USER.ToString());
            }
        }
    }
}