using ILogger = Serilog.ILogger;
using API.Helpers;
using Microsoft.AspNetCore.Mvc;
using Rentify.BAL.Interfaces;
using DB.Models;
using Rentify.DAL.DTOs;

namespace Rentify.API.Controllers
{
    [Route("/Api/Properties")]
    [ApiController]
    public class PropertyController : ControllerBase
    {
        private readonly IPropertyBAL _propertyBal;
        private readonly ILogger _logger;

        public PropertyController(ILogger logger, IPropertyBAL propertyBAL)
        {
            _logger = logger;
            _propertyBal = propertyBAL;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllProperties()
        {
            try
            {
                var properties = await _propertyBal.GetAllPropertiesAsync();
                return ResponseHelper.WrapResponse(200, StatusMessage.SUCCESS.ToString(), properties);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error retrieving properties: {ex.Message}");
                return StatusCode(500);
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetPropertyById(int id)
        {
            try
            {
                var property = await _propertyBal.RetrievePropertyByIdAsync(id);
                return ResponseHelper.WrapResponse(200, StatusMessage.SUCCESS.ToString(), property);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error retrieving property: {ex.Message}");
                return StatusCode(500);
            }
        }

        [HttpPost]
        public async Task<IActionResult> CreateProperty([FromBody] PropertyDto property)
        {
            try
            {
                var newProperty = await _propertyBal.CreatePropertyAsync(property);
                return ResponseHelper.WrapResponse(200, StatusMessage.SUCCESS.ToString(), newProperty);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error creating property: {ex.Message}");
                return StatusCode(500);
            }
        }

        [HttpGet("Owner/{ownerId}")]
        public async Task<IActionResult> GetPropertiesByOwnerId(int ownerId)
        {
            try
            {
                var properties = await _propertyBal.RetrievePropertyByOwnerId(ownerId);
                return ResponseHelper.WrapResponse(200, StatusMessage.SUCCESS.ToString(), properties);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error retrieving properties by owner: {ex.Message}");
                return StatusCode(500);
            }
        }

        [HttpGet("Renter/{renterId}")]
        public async Task<IActionResult> GetPropertiesByRenterId(int renterId)
        {
            try
            {
                var properties = await _propertyBal.RetrievePropertyByRenterId(renterId);
                return ResponseHelper.WrapResponse(200, StatusMessage.SUCCESS.ToString(), properties);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error retrieving properties by owner: {ex.Message}");
                return StatusCode(500);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProperty(int id, [FromBody] PropertyDto property)
        {
            try
            {
                var rowsAffected = await _propertyBal.UpdatePropertyAsync(id, property);
                return ResponseHelper.WrapResponse(200, StatusMessage.SUCCESS.ToString(), rowsAffected);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error updating property: {ex.Message}");
                return StatusCode(500);
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProperty(int id)
        {
            try
            {
                var rowsAffected = await _propertyBal.DeletePropertyAsync(id);
                return ResponseHelper.WrapResponse(200, StatusMessage.SUCCESS.ToString(), rowsAffected);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error deleting property: {ex.Message}");
                return StatusCode(500);
            }
        }

        [HttpGet("Available")]
        public async Task<IActionResult> GetPropertiesAvailable()
        {
            try
            {
                var properties = await _propertyBal.RetrievePropertiesAvailable();
                return ResponseHelper.WrapResponse(200, StatusMessage.SUCCESS.ToString(), properties);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error retrieving available properties: {ex.Message}");
                return StatusCode(500);
            }
        }
    }
}