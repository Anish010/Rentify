using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using API.Helpers;
using BAL.Interfaces;
using DAL.DTOs;
using Microsoft.AspNetCore.Mvc;
using Rentify.API.Helpers;
using ILogger = Serilog.ILogger;

namespace API.Controllers
{
    [Route("/Api/User")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserBAL _userBal;
        private readonly ILogger _logger;

        public UserController(ILogger logger, IUserBAL userBAL)
        {
            _logger = logger;
            _userBal = userBAL;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllUsers()
        {
            try
            {
                var users = await _userBal.GetAllAsync();
                return ResponseHelper.WrapResponse(200, StatusMessage.SUCCESS.ToString(), users);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error retrieving users: {ex.Message}");
                return ResponseHelper.WrapResponse(500, "error", null, ErrorCodes.INTERNAL_SERVER_ERROR.ToString());
            }
        }
    }
}