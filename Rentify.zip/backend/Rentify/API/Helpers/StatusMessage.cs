namespace API.Helpers
{
    public enum StatusMessage
    {
        SUCCESS,
        FAILURE,
        ERROR
    }
}