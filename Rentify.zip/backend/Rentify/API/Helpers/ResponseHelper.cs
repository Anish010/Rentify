using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

public class ResponseHelper
{
    public static IActionResult WrapResponse(int statusCode, string status, object? data, string? errorCode = null)
    {
        var response = new
        {
            status,
            data,
            errorCode
        };
        return new JsonResult(response)
        {
            StatusCode = statusCode
        };
    }
}
