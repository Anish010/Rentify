namespace Rentify.API.Helpers
{
    public enum ErrorCodes
    {
        FAILED_TO_AUTHENTICATE,
        INTERNAL_SERVER_ERROR,
        FAILED_TO_REGISTER_USER
    }
}