import React from "react";
import Lottie from "react-lottie";
import Apartments from "../../assets/animations/Apartments.json";
import "./LandingPage.css";

const LandingPage = () => {
  const appartmentLottie = {
    loop: true,
    autoplay: true,
    animationData: Apartments,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };

  return (
    <div id="lottie-animation" style={{ width: "400px", height: "400px" }}>
      <Lottie
        style={{ display: "inline-block", verticalAlign: "middle" }}
        options={appartmentLottie}
      />
    </div>
  );
};

export default LandingPage;
