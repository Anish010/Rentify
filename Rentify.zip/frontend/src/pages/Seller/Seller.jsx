import React, { useState, useEffect } from "react";
import axios from "axios";
import PropertyForm from "../../components/PropertyForm";
import PropertiesList from "../../components/PropertiesList";
import "./Seller.css";

const SellerDashboard = () => {
  const [properties, setProperties] = useState([]);
  const [editingIndex, setEditingIndex] = useState(null);
  const [editFormData, setEditFormData] = useState(null);

  const API_URL = process.env.API_URL;

  useEffect(() => {
    const authResponse = JSON.parse(localStorage.getItem("authResponse"));
    const userId = authResponse ? authResponse.userId : null;
    console.log(userId);
    if (userId) {
      const fetchProperties = async () => {
        try {
          const response = await axios.get(
            `${API_URL}/Api/Properties/Owner/${userId}`
          );
          setProperties(response.data.data);
        } catch (error) {
          console.error("Error fetching properties:", error);
        }
      };

      fetchProperties();
    }
  }, [API_URL]);

  const addProperty = (property) => {
    setProperties([...properties, property]);
  };

  const updateProperty = (updatedProperty) => {
    const updatedProperties = properties.map((property, index) =>
      index === editingIndex ? updatedProperty : property
    );
    setProperties(updatedProperties);
    setEditingIndex(null);
  };

  const deleteProperty = async (id) => {
    try {
      await axios.delete(`${API_URL}/Api/Properties/${id}`);
      window.location.reload();
      // setProperties(updatedProperties);
    } catch (error) {
      console.error("Error deleting property:", error);
    }
  };

  const editProperty = (id) => {
    const index = properties.findIndex((property) => property.id === id);
    if (index !== -1) {
      setEditingIndex(index);
      setEditFormData(properties[index]);
      console.log("Edit Form Data:", properties[index]);
    }
  };

  return (
    <div className="seller-dashboard">
      <div>
        <PropertyForm
          onSubmit={editingIndex === null ? addProperty : updateProperty}
          initialData={editFormData}
        />
        <PropertiesList
          properties={properties}
          onEdit={(id) => editProperty(id)}
          onDelete={deleteProperty}
        />
      </div>
    </div>
  );
};

export default SellerDashboard;
