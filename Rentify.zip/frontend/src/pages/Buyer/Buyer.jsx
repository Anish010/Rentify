import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  Container,
  Typography,
  Box,
  Grid,
  Paper,
} from "@mui/material";
import RentalPropertyCard from "../../components/RentalPropertyCard"; // Import RentalPropertyCard component
import SellerDetails from "../../components/SellerDetails";
import FilterForm from "../../components/FilterForm";

const Buyer = () => {
  const [selectedProperty, setSelectedProperty] = useState(null);
  const [properties, setProperties] = useState([]);
  const API_URL = process.env.API_URL;
  const [filters, setFilters] = useState({
    // Initialize filters here if needed
  });

  useEffect(() => {
    const fetchAvailableProperties = async () => {
      try {
        const response = await axios.get(
          `${API_URL}/Api/Properties/Available`
        );
        setProperties(response.data.data);
      } catch (error) {
        console.error("Error fetching available properties:", error);
      }
    };

    fetchAvailableProperties();
  }, []);

  const handlePropertySelect = (property) => {
    setSelectedProperty(property);
  };

  const handleFilterChange = (newFilters) => {
    setFilters(newFilters);
  };

  return (
    <Container maxWidth="lg" style={{ marginTop: "24px" }}>
      <Typography variant="h4" gutterBottom>
        Rental Properties
      </Typography>
      <FilterForm onFilterChange={handleFilterChange} />
      <Box marginTop="24px">
        <Grid container spacing={3}>
          {properties.map((property) => (
            <Grid item xs={12} sm={6} md={4} key={property.id}>
              <Paper style={{ padding: "24px" }}>
                <RentalPropertyCard
                  property={property}
                  onSelect={handlePropertySelect}
                />
              </Paper>
            </Grid>
          ))}
        </Grid>
      </Box>
      {selectedProperty && (
        <SellerDetails
          seller={selectedProperty.seller}
          onClose={() => setSelectedProperty(null)}
        />
      )}
    </Container>
  );
};

export default Buyer;