import React, { useEffect, useState } from "react";
import {
  Container,
  TextField,
  Button,
  Typography,
  Box,
  CssBaseline,
  Grid,
} from "@mui/material";
import axios from "axios";

const PropertyForm = ({ onSubmit, initialData }) => {
  const authResponse = JSON.parse(localStorage.getItem("authResponse"));
  const userId = authResponse ? authResponse.userId : null;
  const API_URL = process.env.API_URL;
  const [formData, setFormData] = useState(
    initialData || {
      place: "",
      area: "",
      bedrooms: "",
      bathrooms: "",
      nearbyHospitals: "",
      nearbyColleges: "",
    }
  );

  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
    }
  }, [initialData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (initialData) {
        // Update existing property
        const response = await axios.put(
          `${API_URL}/Api/Properties/${initialData.id}`,
          formData
        );
        console.log("Property updated successfully:", response.data);
      } else {
        // Add new property
        const response = await axios.post(
          `${API_URL}/Api/Properties`,
          formData
        );
        console.log("Property added successfully:", response.data);
      }

      // Clear form data
      setFormData({
        place: "",
        area: "",
        bedrooms: "",
        bathrooms: "",
        nearbyHospitals: "",
        nearbyColleges: "",
        userId: userId,
      });

      // Reload the page
      window.location.reload();
    } catch (error) {
      console.error("Error submitting property:", error);
    }
  };

  return (
    <Container component="main" maxWidth="md">
      <CssBaseline />
      <Box
        sx={{
          marginTop: 8,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}>
        <Typography component="h1" variant="h5">
          {initialData ? "Update Property" : "Add Property Details"}
        </Typography>
        <Box
          component="form"
          onSubmit={handleSubmit}
          noValidate
          sx={{ mt: 2 }}
          className="property-form-box">
          <Grid container spacing={5}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                id="place"
                label="Place"
                name="place"
                value={formData.place}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                id="area"
                label="Area (sq ft)"
                name="area"
                value={formData.area}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                id="bedrooms"
                label="Number of Bedrooms"
                name="bedrooms"
                value={formData.bedrooms}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                id="bathrooms"
                label="Number of Bathrooms"
                name="bathrooms"
                value={formData.bathrooms}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                id="nearbyHospitals"
                label="Nearby Hospitals"
                name="nearbyHospitals"
                value={formData.nearbyHospitals}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                id="nearbyColleges"
                label="Nearby Colleges"
                name="nearbyColleges"
                value={formData.nearbyColleges}
                onChange={handleChange}
              />
            </Grid>
          </Grid>
          <Button
            type="submit"
            fullWidth
            variant="contained"
            sx={{ mt: 3, mb: 2 }}
            onSubmit={handleSubmit}>
            {initialData ? "Update" : "Add"}
          </Button>
        </Box>
      </Box>
    </Container>
  );
};

export default PropertyForm;
