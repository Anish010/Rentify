import React from 'react';
import { Card, CardContent, Typography, IconButton, Box, Button } from '@mui/material';
import ThumbUpIcon from '@mui/icons-material/ThumbUp';
import "../css/PropertyCard.css";

const RentalPropertyCard = ({ property, onInterest }) => {
  return (
    <Card className="property-card" variant="outlined">
      <CardContent>
        <Typography variant="h5" component="div">
          {property.place}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Area: {property.area} sq ft
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Bedrooms: {property.bedrooms}, Bathrooms: {property.bathrooms}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Nearby Hospitals: {property.nearbyHospitals}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Nearby Colleges: {property.nearbyColleges}
        </Typography>
        <Box sx={{ marginTop: 2 }}>
          <Button
            variant="contained"
            color="primary"
            startIcon={<ThumbUpIcon />}
            onClick={onInterest}
          >
            Interested
          </Button>
        </Box>
      </CardContent>
    </Card>
  );
};

export default RentalPropertyCard;
