import React from 'react';
import { Card, CardContent, Typography, IconButton, Box } from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import "../css/PropertyCard.css";

const PropertyCard = ({ property, onEdit, onDelete }) => {
  return (
    <Card className="property-card" variant="outlined" >
      <CardContent>
        <Typography variant="h5" component="div">
          {property.place}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Area: {property.area} sq ft
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Bedrooms: {property.bedrooms}, Bathrooms: {property.bathrooms}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Nearby Hospitals: {property.nearbyHospitals}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Nearby Colleges: {property.nearbyColleges}
        </Typography>
        <Box sx={{ marginTop: 2 }}>
          <IconButton aria-label="edit" onClick={onEdit}>
            <EditIcon />
          </IconButton>
          <IconButton aria-label="delete" onClick={onDelete}>
            <DeleteIcon />
          </IconButton>
        </Box>
      </CardContent>
    </Card>
  );
};

export default PropertyCard;
