import React from "react";
import Lottie from "react-lottie";
import Apartments from "../assets/animations/Apartments.json";

const LandingLottie = () => {
  const appartmentLottie = {
    loop: true,
    autoplay: true,
    animationData: Apartments,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };

  return <Lottie options={appartmentLottie} />;
};

export default LandingLottie;