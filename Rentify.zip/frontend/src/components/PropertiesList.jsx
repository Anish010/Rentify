import React from "react";
import { Container, Grid } from "@mui/material";
import PropertyCard from "./PropertyCard";

import "../css/PropertiesList.css";
const PropertiesList = ({ properties, onEdit, onDelete }) => {
  return (
    <Container
      component="main"
      maxWidth="md"
      className="property-list-container">
      <Grid container spacing={2} sx={{ justifyContent: "space-around" }}>
        {properties.map((property) => (
          <Grid
            item
            key={property.id}
            sx={{ width: "100%", maxWidth: "300px", mb : 2 }}>
            <PropertyCard
              property={property}
              onEdit={() => onEdit(property.id)}
              onDelete={() => onDelete(property.id)}
            />
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default PropertiesList;
