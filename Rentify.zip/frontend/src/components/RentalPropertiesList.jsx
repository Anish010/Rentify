import React, { useState, useEffect } from 'react';
import axios from 'axios';
import RentalPropertyCard from './RentalPropertyCard';

const RentalPropertyList = ({ filters, onSelect }) => {
  const [rentalProperties, setRentalProperties] = useState([]);

  useEffect(() => {
    const fetchRentalProperties = async () => {
      try {
        // Make an API request to fetch rental properties based on filters
        const response = await axios.get(`${process.env.API_URL}/Api/Properties/Available`, {
          params: filters // Pass filters as query parameters
        });
        setRentalProperties(response.data.data);
      } catch (error) {
        console.error('Error fetching rental properties:', error);
      }
    };

    fetchRentalProperties();
  }, [filters]);

  const handleInterest = (property) => {
    onSelect(property);
  };

  return (
    <div>
      {rentalProperties.map((property) => (
        <RentalPropertyCard
          key={property.id}
          property={property}
          onInterest={() => handleInterest(property)}
        />
      ))}
    </div>
  );
};

export default RentalPropertyList;
